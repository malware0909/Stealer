[![Watch the video](http://dl3.joxi.net/drive/2020/05/17/0039/3040/2595808/08/6f59a25570.jpg)](https://youtu.be/Jm6KrLGDBho)

#### The project is no longer maintained by me, This is the last release.
#### Проект мною больше не поддерживается, Это последний релиз.

#### Russian:
#### 🔋 New Update:  Bug fixes / Обновление, теперь проект собирается из коробки стабильно, все методы стиллинга в разных файлах и папках для удобства. Больше не требует установки NuGet пакетов. DotNetZip.dll прямов ресусрах.

+ Cтабильно стал собирать все данные, без пропусков
+ Исправлен сбор данных из Opera browser
+ Почищен от АВ
+ Некоторые строки теперь зашифрованны
+ Добавлена повторая проверка и зачистка следов прибывания

#### English:
Update: now the project can work out of box, all methods of stealing data in different files and folders for convenience. It no longer requires installing NuGet packages. DotNetZip.dll is placed in resources.

+ Stable collect all data, without skipping one
+ Fixed data collection for Opera browser
+ Cleaned from AB
+ Some lines are encrypted now
+ Added a second check and cleaning of traces of getting

#### ☣️ Stealer with sending logs to Telegram bot / Стилер с отправкой лога в телеграм бота
![](http://dl4.joxi.net/drive/2020/05/01/0039/3040/2595808/08/9239ba3967.jpg)
![](https://antiscan.me/images/result/RPkjsJH4jRTa.png)

### Stealer Functionality
+ All bacic browsers Chromium, Edge, Gecko (Mozilla Firefox)
+ Clipboard data
+ Discord Session
+ Telegram Session
+ Outlook
+ Grabber files with saving path directories and scanning subdirectories
+ FileZilla
+ Total Commander
+ Pidgin
+ Psi, Psi+
+ Screenshot
+ PCinfo
+ NordVPN
+ OpenVPN
+ ProtonVPN
### Crypto Wallets
+ Armory
+ Atomic Wallet
+ Bitcoin Core
+ Bytecoin 
+ Dash Core
+ Electrum
+ Ethereum
+ Exodus
+ Jaxx
+ Litecoin Core
+ Monero
+ Zcash
### Additionally
+ All ways to collect logs are random
+ Self-removal after sending the log
+ Log Resubmission Protection

 + ❗️ Написан исключительно в образовательных целях! Я не несу ответственности за использование данного проекта и любых его частей кода.
 + ❗️ Written exclusively for educational purposes! I am not responsible for the use of this project and any parts of it.

### Donation
Telegram: @madcod
BTC: 1JHgjtUed6xD1j9ybRbbXv4ejwRbBiabBG
