﻿using Echelon;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Общие сведения об этой сборке предоставляются следующим набором
// набора атрибутов. Измените значения этих атрибутов для изменения сведений,
// связанные с этой сборкой.
[assembly: AssemblyTitle("Inc.Infrastructur Host Driver")]
[assembly: AssemblyDescription("Control plugin Inc.Infrastructur")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Inc.Infrastructure")]
[assembly: AssemblyProduct("Inc.Infrastructure")]
[assembly: AssemblyCopyright("Inc.Infrastructure  ©  2020 Control plugin Inc.Infrastructur")]
[assembly: AssemblyTrademark("Inc.Infrastructure")]
[assembly: AssemblyCulture("")]

// Установка значения False для параметра ComVisible делает типы в этой сборке невидимыми
// для компонентов COM. Если необходимо обратиться к типу в этой сборке через
// из модели COM задайте для атрибута ComVisible этого типа значение true.
[assembly: ComVisible(false)]

// Следующий GUID представляет идентификатор typelib, если этот проект доступен из модели COM
[assembly: Guid("658ac224-561d-4e46-8703-4f2e682b09c7")]

// Сведения о версии сборки состоят из указанных ниже четырех значений:
//
//      Основной номер версии
//      Дополнительный номер версии
//      Номер сборки
//      Номер редакции
//
// Можно задать все значения или принять номера сборки и редакции по умолчанию 
// используя "*", как показано ниже:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
