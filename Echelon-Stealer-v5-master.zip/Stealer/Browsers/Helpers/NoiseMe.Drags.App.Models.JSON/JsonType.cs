namespace Echelon
{
	public enum JsonType
	{
		String,
		Number,
		Object,
		Array,
		Boolean
	}
}
