namespace Echelon
{
	public struct SZ
	{
		public long Size
		{
			get;
			set;
		}

		public long Type
		{
			get;
			set;
		}
	}
}
